@echo off
title Assistant de Recherche Academique - Installation
color 0B

echo ============================================================
echo   Assistant de Recherche Academique - Installation Windows
echo ============================================================
echo.

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERREUR] Python n'est pas installe ou n'est pas dans le PATH.
    echo.
    echo Installez Python 3.10 ou plus recent depuis :
    echo   https://www.python.org/downloads/
    echo Pendant l'installation, cochez bien "Add Python to PATH".
    echo.
    pause
    exit /b 1
)

echo [1/3] Python detecte. Installation des dependances...
echo.
python -m pip install --upgrade pip
python -m pip install requests scikit-learn langdetect python-docx pypdf

echo.
echo [2/3] Dependances installees.
echo.
echo [3/3] Creation du raccourci de lancement...

echo @echo off > lancer.bat
echo cd /d "%%~dp0" >> lancer.bat
echo python interface_graphique.py >> lancer.bat
echo pause >> lancer.bat

echo.
echo ============================================================
echo   Installation terminee !
echo   Double-cliquez desormais sur "lancer.bat" pour ouvrir
echo   l'Assistant de Recherche Academique.
echo ============================================================
echo.
pause
