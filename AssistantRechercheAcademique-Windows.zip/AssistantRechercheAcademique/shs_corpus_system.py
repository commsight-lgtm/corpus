#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Moteur de recherche académique — toutes filières
=====================================================

Un moteur de recherche pour chercheurs, toutes disciplines confondues
(SHS, sciences, médecine, droit, ingénierie...), qui :

  1. Interroge SIX API PUBLIQUES et OFFICIELLES, sans clé requise :
       - DOAJ              revues à comité de lecture, 100% accès libre
       - Crossref          ~140M références toutes disciplines
       - OpenAlex          ~250M travaux, code de langue fiable par notice
       - HAL               archive ouverte française, toutes disciplines
       - Semantic Scholar   citations reçues par article
       - arXiv             préprints sciences dures (physique, maths,
                            informatique, biologie quantitative...)
     Les six sont interrogées EN PARALLÈLE (threads), puis dédoublonnées
     (par DOI, sinon titre normalisé) en s'enrichissant mutuellement.

  2. Filtre par langue (français, arabe, anglais) — métadonnée si
     disponible, sinon détection automatique.

  3. Calcule un score hybride (TF-IDF sémantique + mots-clés) entre le
     sujet de recherche et chaque résultat.

  4. Permet de copier la référence, d'ouvrir l'article en ligne, de le
     mettre en favori, et d'exporter la bibliographie (.bib / .ris /
     .docx / synchronisation Zotero).

  5. Analyse un document personnel (PDF ou texte collé — ouvrage,
     article, journal, message...) et en extrait les passages les plus
     pertinents pour un sujet de recherche donné, avec numéro de page
     pour les PDF. Même technique de similarité (TF-IDF) que la
     recherche en ligne, pour une cohérence de résultat.

Pourquoi pas ASJP dans cette version :
  Le robots.txt d'ASJP (asjp.cerist.dz) interdit explicitement l'accès
  automatisé. On respecte cette règle. Pour l'intégrer plus tard, la voie
  légale est un partenariat/accès officiel avec le CERIST, ou l'upload
  manuel par l'étudiant de ses propres PDF (déjà possible via l'analyse
  de document ci-dessus).

Limites à connaître :
  - La similarité TF-IDF capte le recouvrement de vocabulaire, pas une
    compréhension sémantique profonde : les passages extraits d'un
    document dépendent du vocabulaire partagé avec le sujet tapé.
  - Pas de LLM dans cette version.

Installation :
    pip install requests scikit-learn langdetect --break-system-packages
    pip install python-docx --break-system-packages   # export .docx
    pip install pypdf --break-system-packages          # analyse de PDF

Lancement (ligne de commande) :
    python3 shs_corpus_system.py

Lancement (interface graphique) :
    python3 interface_graphique.py
"""

from __future__ import annotations

import logging
import re
import sqlite3
import sys
import threading
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

import requests
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

try:
    from langdetect import detect as _detecter_langue, DetectorFactory
    DetectorFactory.seed = 0  # résultats reproductibles
    _LANGDETECT_DISPONIBLE = True
except ImportError:
    _LANGDETECT_DISPONIBLE = False

# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------

DB_PATH = Path(__file__).parent / "academique.db"
LOG_PATH = Path(__file__).parent / "academique.log"

DOAJ_SEARCH_URL = "https://doaj.org/api/search/articles/{query}"
DOAJ_TIMEOUT = 10
DOAJ_PAGE_SIZE = 30

CROSSREF_SEARCH_URL = "https://api.crossref.org/works"
CROSSREF_TIMEOUT = 10
CROSSREF_PAGE_SIZE = 20

OPENALEX_SEARCH_URL = "https://api.openalex.org/works"
OPENALEX_TIMEOUT = 10
OPENALEX_PAGE_SIZE = 20

HAL_SEARCH_URL = "https://api.archives-ouvertes.fr/search/"
HAL_TIMEOUT = 10
HAL_PAGE_SIZE = 20

S2_SEARCH_URL = "https://api.semanticscholar.org/graph/v1/paper/search"
S2_TIMEOUT = 10
S2_PAGE_SIZE = 20
S2_SEARCH_FIELDS = "title,authors,year,venue,abstract,url,externalIds,citationCount"

ARXIV_SEARCH_URL = "http://export.arxiv.org/api/query"
ARXIV_TIMEOUT = 10
ARXIV_PAGE_SIZE = 20
ARXIV_NS = {"atom": "http://www.w3.org/2005/Atom"}

ZOTERO_API_URL = "https://api.zotero.org"
ZOTERO_TIMEOUT = 15

USER_AGENT = "AssistantRechercheAcademique/1.0 (mailto:contact@example.com)"

LANGUES_AUTORISEES = {"FR", "AR", "EN"}


# --------------------------------------------------------------------------
# Journalisation (fichier academique.log + console)
# --------------------------------------------------------------------------

def _configurer_logging() -> logging.Logger:
    logger = logging.getLogger("academique")
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        fh = logging.FileHandler(LOG_PATH, encoding="utf-8")
        fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
        logger.addHandler(fh)

        ch = logging.StreamHandler()
        ch.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(ch)
    return logger


logger = _configurer_logging()


# --------------------------------------------------------------------------
# Modèle de données
# --------------------------------------------------------------------------

@dataclass
class Article:
    id: str
    title: str
    authors: List[str] = field(default_factory=list)
    year: Optional[str] = None
    journal: str = ""
    abstract: str = ""
    keywords: List[str] = field(default_factory=list)
    url: str = ""
    lang: str = ""
    doi: str = ""
    source: str = ""
    citation_count: Optional[int] = None

    def texte_indexable(self) -> str:
        return " ".join([
            self.title or "",
            self.abstract or "",
            " ".join(self.keywords),
        ])

    def reference_academique(self) -> str:
        auteurs = ", ".join(self.authors) if self.authors else "Auteur inconnu"
        annee = self.year or "s.d."
        return f"{auteurs} ({annee}). {self.title}. {self.journal}."

    def cle_bibtex(self) -> str:
        premier_auteur = "Inconnu"
        if self.authors:
            morceaux = self.authors[0].split()
            if morceaux:
                premier_auteur = morceaux[-1]
        premier_auteur = re.sub(r"[^A-Za-zÀ-ÿ]", "", premier_auteur) or "Inconnu"
        annee = re.sub(r"[^0-9]", "", self.year or "") or "sd"
        premier_mot_titre = ""
        if self.title:
            morceaux_titre = self.title.split()
            if morceaux_titre:
                premier_mot_titre = re.sub(r"[^A-Za-zÀ-ÿ]", "", morceaux_titre[0])
        return f"{premier_auteur}{annee}{premier_mot_titre or 'Article'}"

    def vers_bibtex(self) -> str:
        cle = self.cle_bibtex()
        auteurs_bib = " and ".join(self.authors) if self.authors else "Inconnu"
        champs = [
            ("author", auteurs_bib),
            ("title", self.title),
            ("journal", self.journal),
            ("year", self.year or ""),
            ("doi", self.doi),
            ("url", self.url),
        ]
        if self.citation_count is not None:
            champs.append(("note", f"{self.citation_count} citation(s) recensée(s) (Semantic Scholar)"))
        lignes = "\n".join(f"  {nom} = {{{valeur}}}," for nom, valeur in champs if valeur)
        return f"@article{{{cle},\n{lignes}\n}}"

    def vers_ris(self) -> str:
        lignes = ["TY  - JOUR"]
        for auteur in self.authors:
            lignes.append(f"AU  - {auteur}")
        lignes.append(f"TI  - {self.title}")
        if self.journal:
            lignes.append(f"JO  - {self.journal}")
        if self.year:
            lignes.append(f"PY  - {self.year}")
        if self.doi:
            lignes.append(f"DO  - {self.doi}")
        if self.url:
            lignes.append(f"UR  - {self.url}")
        if self.abstract:
            lignes.append(f"AB  - {self.abstract}")
        lignes.append("ER  - ")
        return "\n".join(lignes)


# --------------------------------------------------------------------------
# Export bibliographique
# --------------------------------------------------------------------------

def exporter_bibtex(articles: List[Article], chemin: Path) -> None:
    contenu = "\n\n".join(a.vers_bibtex() for a in articles)
    chemin.write_text(contenu, encoding="utf-8")


def exporter_ris(articles: List[Article], chemin: Path) -> None:
    contenu = "\n\n".join(a.vers_ris() for a in articles)
    chemin.write_text(contenu, encoding="utf-8")


def exporter_docx(articles: List[Article], chemin: Path, titre: str = "Bibliographie") -> None:
    """Génère une bibliographie académique au format Word (.docx), triée
    par nom du premier auteur. Nécessite python-docx :
        pip install python-docx --break-system-packages
    """
    try:
        from docx import Document
        from docx.shared import Pt
    except ImportError as e:
        raise RuntimeError(
            "L'export .docx nécessite le paquet python-docx. Installez-le avec :\n"
            "pip install python-docx --break-system-packages"
        ) from e

    document = Document()
    document.add_heading(titre, level=1)

    def cle_tri(article: Article) -> str:
        if article.authors and article.authors[0].split():
            return article.authors[0].split()[-1].lower()
        return "zzz"

    for article in sorted(articles, key=cle_tri):
        paragraphe = document.add_paragraph(article.reference_academique())
        paragraphe.paragraph_format.space_after = Pt(10)
        paragraphe.paragraph_format.left_indent = Pt(18)
        paragraphe.paragraph_format.first_line_indent = Pt(-18)

    document.save(str(chemin))


# --------------------------------------------------------------------------
# Nettoyage de requête (syntaxe Elasticsearch/Lucene utilisée par DOAJ)
# --------------------------------------------------------------------------

_CARACTERES_SPECIAUX_LUCENE = re.compile(r'[+\-!(){}\[\]^"~*?:\\/]')


def nettoyer_requete_lucene(requete: str) -> str:
    sans_caracteres_speciaux = _CARACTERES_SPECIAUX_LUCENE.sub(" ", requete)
    return " ".join(sans_caracteres_speciaux.split())


_ALIAS_LANGUES = {
    "FRENCH": "FR", "FRANÇAIS": "FR", "FRANCAIS": "FR", "FR": "FR",
    "ARABIC": "AR", "ARABE": "AR", "AR": "AR",
    "ENGLISH": "EN", "ANGLAIS": "EN", "EN": "EN",
}


def _normaliser_codes_langue(brut: str) -> List[str]:
    if not brut:
        return []
    codes = []
    for morceau in re.split(r"[,/|]", brut):
        cle = morceau.strip().upper()
        if cle in _ALIAS_LANGUES:
            codes.append(_ALIAS_LANGUES[cle])
    return codes


def langue_autorisee(article: "Article") -> bool:
    codes = _normaliser_codes_langue(article.lang)
    if codes:
        return any(c in LANGUES_AUTORISEES for c in codes)

    if not _LANGDETECT_DISPONIBLE:
        return False

    texte = (article.title + " " + article.abstract).strip()
    if len(texte) < 20:
        return False
    try:
        detectee = _detecter_langue(texte).upper()
    except Exception:
        return False
    return detectee in LANGUES_AUTORISEES


# --------------------------------------------------------------------------
# Requêtes HTTP robustes (reprises automatiques sur erreur transitoire)
# --------------------------------------------------------------------------

def requete_avec_reprises(url: str, *, tentatives: int = 3, delai_initial: float = 1.0,
                           **kwargs) -> requests.Response:
    delai = delai_initial
    derniere_erreur: Optional[Exception] = None
    for tentative in range(1, tentatives + 1):
        try:
            resp = requests.get(url, **kwargs)
        except requests.RequestException as e:
            derniere_erreur = e
        else:
            if resp.status_code == 429 or resp.status_code >= 500:
                derniere_erreur = requests.RequestException(f"Erreur temporaire {resp.status_code}")
            else:
                resp.raise_for_status()
                return resp

        if tentative < tentatives:
            logger.warning(f"Tentative {tentative}/{tentatives} échouée ({derniere_erreur}). "
                            f"Nouvel essai dans {delai:.0f}s…")
            time.sleep(delai)
            delai *= 2
    assert derniere_erreur is not None
    raise derniere_erreur


# --------------------------------------------------------------------------
# Client DOAJ
# --------------------------------------------------------------------------

class DOAJClient:
    """Interroge l'API publique de DOAJ (https://doaj.org/api/docs)."""

    def __init__(self, timeout: int = DOAJ_TIMEOUT):
        self.timeout = timeout

    def rechercher(self, requete: str, max_resultats: int = DOAJ_PAGE_SIZE) -> List[Article]:
        requete_nettoyee = nettoyer_requete_lucene(requete)
        if not requete_nettoyee:
            return []
        url = DOAJ_SEARCH_URL.format(query=requete_nettoyee)
        try:
            resp = requete_avec_reprises(
                url, params={"pageSize": max_resultats}, timeout=self.timeout,
                headers={"User-Agent": USER_AGENT},
            )
            data = resp.json()
        except requests.RequestException as e:
            logger.warning(f"DOAJ indisponible ({e}). Recherche limitée au cache local.")
            return []
        except ValueError:
            logger.warning("Réponse DOAJ illisible (format inattendu).")
            return []

        articles = []
        for item in data.get("results", []):
            article = self._parse_article(item)
            if article and langue_autorisee(article):
                articles.append(article)
        return articles

    @staticmethod
    def _parse_article(item: dict) -> Optional[Article]:
        try:
            bib = item.get("bibjson", {})
            titre = bib.get("title", "").strip()
            if not titre:
                return None

            auteurs = [a.get("name", "").strip() for a in bib.get("author", []) if a.get("name")]
            annee = bib.get("year")
            journal = bib.get("journal", {}).get("title", "")
            langues = bib.get("journal", {}).get("language", [])
            abstract = bib.get("abstract", "") or ""
            mots_cles = bib.get("keywords", []) or []

            lien_texte_integral = ""
            for lien in bib.get("link", []):
                if lien.get("type") == "fulltext":
                    lien_texte_integral = lien.get("url", "")
                    break

            doi = ""
            for identifiant in bib.get("identifier", []):
                if identifiant.get("type", "").lower() == "doi":
                    doi = identifiant.get("id", "")
                    break

            return Article(
                id=f"doaj:{item.get('id', titre[:50])}",
                title=titre, authors=auteurs, year=str(annee) if annee else None,
                journal=journal, abstract=abstract, keywords=mots_cles,
                url=lien_texte_integral, lang=",".join(langues) if langues else "",
                doi=doi, source="DOAJ",
            )
        except Exception:
            return None


# --------------------------------------------------------------------------
# Client Crossref
# --------------------------------------------------------------------------

class CrossrefClient:
    """Interroge l'API publique de Crossref (https://api.crossref.org)."""

    def __init__(self, timeout: int = CROSSREF_TIMEOUT):
        self.timeout = timeout

    def rechercher(self, requete: str, max_resultats: int = CROSSREF_PAGE_SIZE) -> List[Article]:
        requete_nettoyee = nettoyer_requete_lucene(requete)
        if not requete_nettoyee:
            return []
        try:
            resp = requete_avec_reprises(
                CROSSREF_SEARCH_URL,
                params={"query": requete_nettoyee, "rows": max_resultats},
                timeout=self.timeout, headers={"User-Agent": USER_AGENT},
            )
            data = resp.json()
        except requests.RequestException as e:
            logger.warning(f"Crossref indisponible ({e}).")
            return []
        except ValueError:
            logger.warning("Réponse Crossref illisible (format inattendu).")
            return []

        articles = []
        for item in data.get("message", {}).get("items", []):
            article = self._parse_article(item)
            if article and langue_autorisee(article):
                articles.append(article)
        return articles

    @staticmethod
    def _parse_article(item: dict) -> Optional[Article]:
        try:
            titres = item.get("title", [])
            titre = titres[0].strip() if titres else ""
            if not titre:
                return None

            auteurs = []
            for a in item.get("author", []):
                nom = " ".join(p for p in [a.get("given", ""), a.get("family", "")] if p).strip()
                if nom:
                    auteurs.append(nom)

            annee = None
            date_parts = item.get("issued", {}).get("date-parts", [[]])
            if date_parts and date_parts[0]:
                annee = str(date_parts[0][0])

            journal_liste = item.get("container-title", [])
            journal = journal_liste[0] if journal_liste else ""

            doi = item.get("DOI", "") or ""
            url = item.get("URL", "") or (f"https://doi.org/{doi}" if doi else "")

            return Article(
                id=f"crossref:{doi or titre[:50]}",
                title=titre, authors=auteurs, year=annee, journal=journal,
                abstract="", keywords=item.get("subject", []) or [],
                url=url, lang=item.get("language", "") or "",
                doi=doi, source="Crossref",
            )
        except Exception:
            return None


# --------------------------------------------------------------------------
# Client OpenAlex
# --------------------------------------------------------------------------

class OpenAlexClient:
    """Interroge l'API publique d'OpenAlex (https://openalex.org)."""

    def __init__(self, timeout: int = OPENALEX_TIMEOUT):
        self.timeout = timeout

    def rechercher(self, requete: str, max_resultats: int = OPENALEX_PAGE_SIZE) -> List[Article]:
        requete_nettoyee = nettoyer_requete_lucene(requete)
        if not requete_nettoyee:
            return []
        try:
            resp = requete_avec_reprises(
                OPENALEX_SEARCH_URL,
                params={"search": requete_nettoyee, "per_page": max_resultats},
                timeout=self.timeout, headers={"User-Agent": USER_AGENT},
            )
            data = resp.json()
        except requests.RequestException as e:
            logger.warning(f"OpenAlex indisponible ({e}).")
            return []
        except ValueError:
            logger.warning("Réponse OpenAlex illisible (format inattendu).")
            return []

        articles = []
        for item in data.get("results", []):
            article = self._parse_article(item)
            if article and langue_autorisee(article):
                articles.append(article)
        return articles

    @staticmethod
    def _reconstruire_resume(index_inverse: Optional[dict]) -> str:
        if not index_inverse:
            return ""
        positions: Dict[int, str] = {}
        for mot, indices in index_inverse.items():
            for i in indices:
                positions[i] = mot
        if not positions:
            return ""
        return " ".join(positions[i] for i in sorted(positions))

    @classmethod
    def _parse_article(cls, item: dict) -> Optional[Article]:
        try:
            titre = (item.get("title") or item.get("display_name") or "").strip()
            if not titre:
                return None

            auteurs = []
            for a in item.get("authorships", []):
                nom = a.get("author", {}).get("display_name", "")
                if nom:
                    auteurs.append(nom)

            annee = item.get("publication_year")
            source_info = (item.get("primary_location") or {}).get("source") or {}
            journal = source_info.get("display_name", "") or ""

            doi_brut = item.get("doi", "") or ""
            doi = doi_brut.replace("https://doi.org/", "") if doi_brut else ""

            url = ((item.get("open_access") or {}).get("oa_url")
                   or (item.get("primary_location") or {}).get("landing_page_url")
                   or (f"https://doi.org/{doi}" if doi else ""))

            resume = cls._reconstruire_resume(item.get("abstract_inverted_index"))
            mots_cles = [
                c.get("display_name", "") for c in item.get("concepts", [])[:8]
                if c.get("display_name")
            ]

            return Article(
                id=f"openalex:{item.get('id', titre[:50])}",
                title=titre, authors=auteurs, year=str(annee) if annee else None,
                journal=journal, abstract=resume, keywords=mots_cles,
                url=url, lang=item.get("language", "") or "",
                doi=doi, source="OpenAlex",
            )
        except Exception:
            return None


# --------------------------------------------------------------------------
# Client HAL
# --------------------------------------------------------------------------

class HALClient:
    """Interroge l'API publique de HAL (https://api.archives-ouvertes.fr) —
    archive ouverte française, toutes disciplines."""

    def __init__(self, timeout: int = HAL_TIMEOUT):
        self.timeout = timeout

    def rechercher(self, requete: str, max_resultats: int = HAL_PAGE_SIZE) -> List[Article]:
        requete_nettoyee = nettoyer_requete_lucene(requete)
        if not requete_nettoyee:
            return []
        params = {
            "q": requete_nettoyee, "wt": "json", "rows": max_resultats,
            "fl": "title_s,authFullName_s,producedDateY_i,journalTitle_s,"
                  "abstract_s,keyword_s,uri_s,doiId_s,language_s",
        }
        try:
            resp = requete_avec_reprises(
                HAL_SEARCH_URL, params=params, timeout=self.timeout,
                headers={"User-Agent": USER_AGENT},
            )
            data = resp.json()
        except requests.RequestException as e:
            logger.warning(f"HAL indisponible ({e}).")
            return []
        except ValueError:
            logger.warning("Réponse HAL illisible (format inattendu).")
            return []

        articles = []
        for item in data.get("response", {}).get("docs", []):
            article = self._parse_article(item)
            if article and langue_autorisee(article):
                articles.append(article)
        return articles

    @staticmethod
    def _parse_article(item: dict) -> Optional[Article]:
        try:
            titres = item.get("title_s", [])
            titre = titres[0].strip() if titres else ""
            if not titre:
                return None

            auteurs = item.get("authFullName_s", []) or []
            annee = item.get("producedDateY_i")
            journal = item.get("journalTitle_s", "") or ""
            abstract_liste = item.get("abstract_s", [])
            abstract = abstract_liste[0] if abstract_liste else ""
            mots_cles = item.get("keyword_s", []) or []
            url = item.get("uri_s", "") or ""
            doi = item.get("doiId_s", "") or ""
            langues = item.get("language_s", []) or []

            return Article(
                id=f"hal:{item.get('uri_s', titre[:50])}",
                title=titre, authors=auteurs, year=str(annee) if annee else None,
                journal=journal, abstract=abstract, keywords=mots_cles,
                url=url, lang=",".join(langues) if langues else "",
                doi=doi, source="HAL",
            )
        except Exception:
            return None


# --------------------------------------------------------------------------
# Client Semantic Scholar
# --------------------------------------------------------------------------

class SemanticScholarClient:
    """Interroge l'API publique de Semantic Scholar
    (https://api.semanticscholar.org). Apporte le nombre de citations par
    article, toutes disciplines."""

    def __init__(self, timeout: int = S2_TIMEOUT):
        self.timeout = timeout

    def rechercher(self, requete: str, max_resultats: int = S2_PAGE_SIZE) -> List[Article]:
        requete_nettoyee = nettoyer_requete_lucene(requete)
        if not requete_nettoyee:
            return []
        params = {"query": requete_nettoyee, "limit": max_resultats, "fields": S2_SEARCH_FIELDS}
        try:
            resp = requete_avec_reprises(
                S2_SEARCH_URL, params=params, timeout=self.timeout,
                headers={"User-Agent": USER_AGENT},
            )
            data = resp.json()
        except requests.RequestException as e:
            logger.warning(f"Semantic Scholar indisponible ({e}).")
            return []
        except ValueError:
            logger.warning("Réponse Semantic Scholar illisible (format inattendu).")
            return []

        articles = []
        for item in data.get("data", []):
            article = self._parse_article(item)
            if article and langue_autorisee(article):
                articles.append(article)
        return articles

    @staticmethod
    def _parse_article(item: dict) -> Optional[Article]:
        try:
            titre = (item.get("title") or "").strip()
            if not titre:
                return None

            auteurs = [a.get("name", "") for a in item.get("authors", []) if a.get("name")]
            annee = item.get("year")
            journal = item.get("venue", "") or ""
            abstract = item.get("abstract", "") or ""
            doi = (item.get("externalIds") or {}).get("DOI", "") or ""
            url = item.get("url", "") or (f"https://doi.org/{doi}" if doi else "")
            citations = item.get("citationCount")

            return Article(
                id=f"s2:{doi or titre[:50]}",
                title=titre, authors=auteurs, year=str(annee) if annee else None,
                journal=journal, abstract=abstract, keywords=[],
                url=url, lang="", doi=doi, source="Semantic Scholar",
                citation_count=citations if isinstance(citations, int) else None,
            )
        except Exception:
            return None


# --------------------------------------------------------------------------
# Client arXiv — préprints en sciences dures
# --------------------------------------------------------------------------

class ArxivClient:
    """Interroge l'API publique d'arXiv (https://arxiv.org/help/api) —
    préprints en physique, mathématiques, informatique, biologie
    quantitative, statistiques... Complète les autres sources pour les
    filières scientifiques et techniques."""

    def __init__(self, timeout: int = ARXIV_TIMEOUT):
        self.timeout = timeout

    def rechercher(self, requete: str, max_resultats: int = ARXIV_PAGE_SIZE) -> List[Article]:
        requete_nettoyee = nettoyer_requete_lucene(requete)
        if not requete_nettoyee:
            return []
        params = {"search_query": f"all:{requete_nettoyee}", "start": 0, "max_results": max_resultats}
        try:
            resp = requete_avec_reprises(
                ARXIV_SEARCH_URL, params=params, timeout=self.timeout,
                headers={"User-Agent": USER_AGENT},
            )
            racine = ET.fromstring(resp.content)
        except requests.RequestException as e:
            logger.warning(f"arXiv indisponible ({e}).")
            return []
        except ET.ParseError:
            logger.warning("Réponse arXiv illisible (XML invalide).")
            return []

        articles = []
        for entree in racine.findall("atom:entry", ARXIV_NS):
            article = self._parse_article(entree)
            if article and langue_autorisee(article):
                articles.append(article)
        return articles

    @staticmethod
    def _parse_article(entree) -> Optional[Article]:
        try:
            titre_el = entree.find("atom:title", ARXIV_NS)
            titre = (titre_el.text or "").strip().replace("\n", " ") if titre_el is not None else ""
            if not titre:
                return None

            auteurs = [
                (a.find("atom:name", ARXIV_NS).text or "").strip()
                for a in entree.findall("atom:author", ARXIV_NS)
                if a.find("atom:name", ARXIV_NS) is not None
            ]

            id_el = entree.find("atom:id", ARXIV_NS)
            url = id_el.text.strip() if id_el is not None and id_el.text else ""

            publie_el = entree.find("atom:published", ARXIV_NS)
            annee = publie_el.text[:4] if publie_el is not None and publie_el.text else None

            resume_el = entree.find("atom:summary", ARXIV_NS)
            resume = (resume_el.text or "").strip().replace("\n", " ") if resume_el is not None else ""

            return Article(
                id=f"arxiv:{url or titre[:50]}",
                title=titre, authors=auteurs, year=annee, journal="arXiv (preprint)",
                abstract=resume, keywords=[], url=url, lang="",
                source="arXiv",
            )
        except Exception:
            return None


# --------------------------------------------------------------------------
# Client Zotero — synchronisation vers une bibliothèque personnelle
# --------------------------------------------------------------------------

class ZoteroClient:
    """Envoie des références vers une bibliothèque Zotero personnelle via
    l'API officielle (https://www.zotero.org/support/dev/web_api/v3/start).
    Nécessite une clé API Zotero et l'identifiant numérique de la
    bibliothèque (userID) — les deux se créent/trouvent sur
    https://www.zotero.org/settings/keys."""

    def __init__(self, api_key: str, library_id: str, library_type: str = "user"):
        self.api_key = api_key
        self.library_id = library_id
        self.library_type = library_type

    def _base_url(self) -> str:
        return f"{ZOTERO_API_URL}/{self.library_type}s/{self.library_id}"

    def _headers(self) -> dict:
        return {
            "Zotero-API-Version": "3",
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    @staticmethod
    def _nom_vers_createur(nom: str) -> dict:
        morceaux = nom.strip().split()
        if len(morceaux) <= 1:
            return {"creatorType": "author", "lastName": nom.strip(), "fieldMode": 1}
        return {
            "creatorType": "author",
            "firstName": " ".join(morceaux[:-1]),
            "lastName": morceaux[-1],
        }

    def _article_vers_item(self, article: Article) -> dict:
        item = {
            "itemType": "journalArticle",
            "title": article.title,
            "creators": [self._nom_vers_createur(a) for a in article.authors],
            "abstractNote": article.abstract,
            "publicationTitle": article.journal,
            "date": article.year or "",
            "DOI": article.doi,
            "url": article.url,
        }
        if article.source:
            item["extra"] = f"Source : {article.source}"
        return item

    def deja_present(self, doi: str) -> bool:
        """Vérifie si un DOI est déjà présent dans la bibliothèque, pour
        éviter les doublons lors de l'envoi."""
        if not doi:
            return False
        try:
            resp = requests.get(
                f"{self._base_url()}/items", headers=self._headers(),
                params={"q": doi, "qmode": "everything", "limit": 1},
                timeout=ZOTERO_TIMEOUT,
            )
            resp.raise_for_status()
            return len(resp.json()) > 0
        except requests.RequestException as e:
            logger.warning(f"Vérification Zotero impossible ({e}) — envoi sans dédoublonnage.")
            return False
        except ValueError:
            return False

    def envoyer_articles(self, articles: List[Article], eviter_doublons: bool = True) -> Dict[str, int]:
        """Envoie une liste d'articles vers Zotero, par lots de 50 (limite
        de l'API). Retourne un résumé {'envoyes', 'ignores_doublons', 'echecs'}."""
        resume = {"envoyes": 0, "ignores_doublons": 0, "echecs": 0}
        a_envoyer = []
        for article in articles:
            if eviter_doublons and article.doi and self.deja_present(article.doi):
                resume["ignores_doublons"] += 1
                continue
            a_envoyer.append(article)

        for i in range(0, len(a_envoyer), 50):
            lot = a_envoyer[i:i + 50]
            items = [self._article_vers_item(a) for a in lot]
            try:
                resp = requests.post(
                    f"{self._base_url()}/items", headers=self._headers(),
                    json=items, timeout=ZOTERO_TIMEOUT,
                )
                resp.raise_for_status()
                data = resp.json()
                resume["envoyes"] += len(data.get("success", {}))
                resume["echecs"] += len(data.get("failed", {}))
            except requests.RequestException as e:
                logger.warning(f"Envoi Zotero échoué pour un lot ({e}).")
                resume["echecs"] += len(lot)
            except ValueError:
                resume["echecs"] += len(lot)

        return resume


# --------------------------------------------------------------------------
# Base locale (cache + recherche mots-clés + favoris + paramètres)
# --------------------------------------------------------------------------

class IndexLocal:
    """Base SQLite locale : cache des articles déjà vus, recherche
    full-text, favoris simples, et paramètres (identifiants Zotero).

    Thread-safety : `check_same_thread=False` + `self._verrou` (un
    threading.Lock) permettent un usage sûr depuis le thread d'arrière-
    plan de l'interface graphique.
    """

    def __init__(self, db_path: Path = DB_PATH):
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._verrou = threading.Lock()
        self._init_schema()

    def _init_schema(self):
        with self._verrou:
            self.conn.executescript("""
                CREATE TABLE IF NOT EXISTS articles (
                    id TEXT PRIMARY KEY,
                    title TEXT,
                    authors TEXT,
                    year TEXT,
                    journal TEXT,
                    abstract TEXT,
                    keywords TEXT,
                    url TEXT,
                    lang TEXT,
                    doi TEXT,
                    source TEXT,
                    citation_count INTEGER
                );
                CREATE VIRTUAL TABLE IF NOT EXISTS articles_fts USING fts5(
                    id UNINDEXED, title, abstract, keywords
                );
                CREATE TABLE IF NOT EXISTS favoris (
                    id TEXT PRIMARY KEY,
                    date_ajout TEXT DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS config (
                    cle TEXT PRIMARY KEY,
                    valeur TEXT
                );
            """)
            colonnes_articles = {row["name"] for row in self.conn.execute("PRAGMA table_info(articles)")}
            for colonne, type_sql in (("doi", "TEXT"), ("source", "TEXT"), ("citation_count", "INTEGER")):
                if colonne not in colonnes_articles:
                    self.conn.execute(f"ALTER TABLE articles ADD COLUMN {colonne} {type_sql}")
            self.conn.commit()

    def ajouter(self, articles: List[Article]):
        with self._verrou:
            for a in articles:
                self.conn.execute(
                    """INSERT OR REPLACE INTO articles
                       (id, title, authors, year, journal, abstract, keywords, url, lang,
                        doi, source, citation_count)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (a.id, a.title, "|".join(a.authors), a.year, a.journal,
                     a.abstract, "|".join(a.keywords), a.url, a.lang,
                     a.doi, a.source, a.citation_count),
                )
                self.conn.execute("DELETE FROM articles_fts WHERE id = ?", (a.id,))
                self.conn.execute(
                    "INSERT INTO articles_fts (id, title, abstract, keywords) VALUES (?, ?, ?, ?)",
                    (a.id, a.title, a.abstract, " ".join(a.keywords)),
                )
            self.conn.commit()

    def recherche_mots_cles(self, requete: str, limite: int = 80) -> List[Article]:
        termes = [t for t in requete.replace('"', " ").split() if t]
        if not termes:
            return []
        requete_fts = " OR ".join(f'"{t}"' for t in termes)
        with self._verrou:
            try:
                rows = self.conn.execute(
                    """SELECT articles.* FROM articles_fts
                       JOIN articles ON articles.id = articles_fts.id
                       WHERE articles_fts MATCH ?
                       LIMIT ?""",
                    (requete_fts, limite),
                ).fetchall()
            except sqlite3.OperationalError:
                return []
        return [self._row_vers_article(r) for r in rows]

    def tout(self) -> List[Article]:
        with self._verrou:
            rows = self.conn.execute("SELECT * FROM articles").fetchall()
        return [self._row_vers_article(r) for r in rows]

    def ajouter_favori(self, article_id: str):
        with self._verrou:
            self.conn.execute("INSERT OR IGNORE INTO favoris (id) VALUES (?)", (article_id,))
            self.conn.commit()

    def retirer_favori(self, article_id: str):
        with self._verrou:
            self.conn.execute("DELETE FROM favoris WHERE id = ?", (article_id,))
            self.conn.commit()

    def est_favori(self, article_id: str) -> bool:
        with self._verrou:
            row = self.conn.execute("SELECT 1 FROM favoris WHERE id = ?", (article_id,)).fetchone()
        return row is not None

    def lister_favoris(self) -> List[Article]:
        with self._verrou:
            rows = self.conn.execute(
                """SELECT articles.* FROM favoris
                   JOIN articles ON articles.id = favoris.id
                   ORDER BY favoris.date_ajout DESC"""
            ).fetchall()
        return [self._row_vers_article(r) for r in rows]

    def definir_parametre(self, cle: str, valeur: str):
        with self._verrou:
            self.conn.execute("INSERT OR REPLACE INTO config (cle, valeur) VALUES (?, ?)", (cle, valeur))
            self.conn.commit()

    def obtenir_parametre(self, cle: str) -> Optional[str]:
        with self._verrou:
            row = self.conn.execute("SELECT valeur FROM config WHERE cle = ?", (cle,)).fetchone()
        return row["valeur"] if row else None

    @staticmethod
    def _row_vers_article(row: sqlite3.Row) -> Article:
        cles = row.keys()
        citation_brut = row["citation_count"] if "citation_count" in cles else None
        return Article(
            id=row["id"], title=row["title"],
            authors=row["authors"].split("|") if row["authors"] else [],
            year=row["year"], journal=row["journal"], abstract=row["abstract"],
            keywords=row["keywords"].split("|") if row["keywords"] else [],
            url=row["url"], lang=row["lang"],
            doi=row["doi"] if "doi" in cles and row["doi"] else "",
            source=row["source"] if "source" in cles and row["source"] else "",
            citation_count=int(citation_brut) if citation_brut is not None else None,
        )


# --------------------------------------------------------------------------
# Moteur hybride : six sources + mots-clés + similarité sémantique
# --------------------------------------------------------------------------

class MoteurHybride:
    """Combine six sources (DOAJ, Crossref, OpenAlex, HAL, Semantic
    Scholar, arXiv), un dédoublonnage avec enrichissement, une recherche
    mots-clés (FTS5) et une similarité sémantique (TF-IDF)."""

    def __init__(self, doaj: DOAJClient, index: IndexLocal,
                 crossref: Optional[CrossrefClient] = None,
                 openalex: Optional[OpenAlexClient] = None,
                 hal: Optional[HALClient] = None,
                 semantic_scholar: Optional[SemanticScholarClient] = None,
                 arxiv: Optional[ArxivClient] = None):
        self.doaj = doaj
        self.index = index
        self.crossref = crossref or CrossrefClient()
        self.openalex = openalex or OpenAlexClient()
        self.hal = hal or HALClient()
        self.semantic_scholar = semantic_scholar or SemanticScholarClient()
        self.arxiv = arxiv or ArxivClient()

    @staticmethod
    def _cle_dedoublonnage(article: Article) -> str:
        if article.doi:
            return f"doi:{article.doi.lower().strip()}"
        titre_normalise = re.sub(r"[^a-z0-9]", "", article.title.lower())
        return f"titre:{titre_normalise}"

    @staticmethod
    def _fusionner_dans(existant: Article, nouveau: Article) -> None:
        if not existant.abstract and nouveau.abstract:
            existant.abstract = nouveau.abstract
        if not existant.url and nouveau.url:
            existant.url = nouveau.url
        if not existant.doi and nouveau.doi:
            existant.doi = nouveau.doi
        if existant.citation_count is None and nouveau.citation_count is not None:
            existant.citation_count = nouveau.citation_count
        if not existant.keywords and nouveau.keywords:
            existant.keywords = nouveau.keywords

    def _interroger_sources(self, sujet: str) -> List[Article]:
        resultats_par_source: Dict[str, List[Article]] = {}

        def _lancer(nom: str, fonction):
            try:
                resultats_par_source[nom] = fonction(sujet)
            except Exception as e:
                logger.warning(f"Erreur inattendue en interrogeant {nom} : {e}")
                resultats_par_source[nom] = []

        fils = [
            threading.Thread(target=_lancer, args=("DOAJ", self.doaj.rechercher)),
            threading.Thread(target=_lancer, args=("Crossref", self.crossref.rechercher)),
            threading.Thread(target=_lancer, args=("OpenAlex", self.openalex.rechercher)),
            threading.Thread(target=_lancer, args=("HAL", self.hal.rechercher)),
            threading.Thread(target=_lancer, args=("Semantic Scholar", self.semantic_scholar.rechercher)),
            threading.Thread(target=_lancer, args=("arXiv", self.arxiv.rechercher)),
        ]
        for f in fils:
            f.start()
        for f in fils:
            f.join()

        tous: List[Article] = []
        for nom, articles in resultats_par_source.items():
            logger.info(f"{nom} : {len(articles)} résultat(s) pertinent(s) pour « {sujet} ».")
            tous.extend(articles)
        return tous

    def rechercher(self, sujet: str, top_k: int = 30) -> List[tuple[Article, float]]:
        nouveaux = self._interroger_sources(sujet)

        candidats: Dict[str, Article] = {}
        for a in nouveaux:
            cle = self._cle_dedoublonnage(a)
            if cle in candidats:
                self._fusionner_dans(candidats[cle], a)
            else:
                candidats[cle] = a
        if candidats:
            self.index.ajouter(list(candidats.values()))

        for a in self.index.recherche_mots_cles(sujet):
            if langue_autorisee(a):
                candidats.setdefault(self._cle_dedoublonnage(a), a)
        if not candidats:
            return []

        articles = list(candidats.values())

        textes = [sujet] + [a.texte_indexable() for a in articles]
        try:
            vect = TfidfVectorizer(max_features=5000)
            matrice = vect.fit_transform(textes)
            scores_semantiques = cosine_similarity(matrice[0:1], matrice[1:]).flatten()
        except ValueError:
            scores_semantiques = [0.0] * len(articles)

        termes_sujet = set(w.lower() for w in sujet.split() if len(w) > 2)

        def score_mots_cles(article: Article) -> float:
            if not termes_sujet:
                return 0.0
            texte = article.texte_indexable().lower()
            presents = sum(1 for t in termes_sujet if t in texte)
            return presents / len(termes_sujet)

        resultats = []
        for article, score_sem in zip(articles, scores_semantiques):
            score_mc = score_mots_cles(article)
            score_final = 0.6 * score_sem + 0.4 * score_mc
            resultats.append((article, round(float(score_final), 3)))

        resultats.sort(key=lambda x: x[1], reverse=True)
        return resultats[:top_k]


# --------------------------------------------------------------------------
# Analyse de document personnel (PDF ou texte collé) — extraction de
# passages pertinents pour un sujet de recherche
# --------------------------------------------------------------------------

def extraire_pages_pdf(chemin: Path) -> List[str]:
    """Extrait le texte de chaque page d'un PDF. Nécessite pypdf :
        pip install pypdf --break-system-packages
    """
    try:
        from pypdf import PdfReader
    except ImportError as e:
        raise RuntimeError(
            "L'analyse de PDF nécessite le paquet pypdf. Installez-le avec :\n"
            "pip install pypdf --break-system-packages"
        ) from e

    lecteur = PdfReader(str(chemin))
    pages = []
    for page in lecteur.pages:
        try:
            pages.append(page.extract_text() or "")
        except Exception:
            pages.append("")
    return pages


_DECOUPE_PHRASES = re.compile(r'(?<=[.!?])\s+')


def _decouper_en_phrases(texte: str) -> List[str]:
    phrases = _DECOUPE_PHRASES.split(texte.replace("\n", " ").strip())
    return [p.strip() for p in phrases if len(p.strip()) >= 25]


def extraire_passages_pertinents(unites: List[Dict[str, object]], sujet: str,
                                  max_resultats: int = 15) -> List[Dict[str, object]]:
    """Découpe un ou plusieurs blocs de texte (pages d'un PDF, ou texte
    collé) en phrases, puis les classe par pertinence pour un sujet de
    recherche — même technique de similarité (TF-IDF) que le moteur de
    recherche principal, pour une cohérence de résultat.

    Chaque unité est un dict {"texte": str, "page": Optional[int]}.
    Retourne les passages les plus pertinents avec leur score et, si
    disponible, leur numéro de page — prêts à citer.

    Limite à connaître : le score reflète un recouvrement de vocabulaire,
    pas une compréhension du sens ; un passage important mais formulé
    avec d'autres mots que le sujet peut être sous-estimé."""
    candidats: List[Dict[str, object]] = []
    for unite in unites:
        page = unite.get("page")
        for phrase in _decouper_en_phrases(str(unite.get("texte", ""))):
            candidats.append({"texte": phrase, "page": page})

    if not candidats or not sujet.strip():
        return []

    textes = [sujet] + [str(c["texte"]) for c in candidats]
    try:
        vect = TfidfVectorizer(max_features=5000)
        matrice = vect.fit_transform(textes)
        scores = cosine_similarity(matrice[0:1], matrice[1:]).flatten()
    except ValueError:
        return []

    for candidat, score in zip(candidats, scores):
        candidat["score"] = round(float(score), 3)

    candidats.sort(key=lambda c: c["score"], reverse=True)

    vues = set()
    resultat = []
    for c in candidats:
        cle = str(c["texte"])[:80]
        if cle in vues or c["score"] <= 0:
            continue
        vues.add(cle)
        resultat.append(c)
        if len(resultat) >= max_resultats:
            break
    return resultat


# --------------------------------------------------------------------------
# Interface en ligne de commande (barre de recherche minimale)
# --------------------------------------------------------------------------

def afficher_resultats(resultats: List[tuple[Article, float]]):
    if not resultats:
        print("\nAucun résultat pertinent trouvé. Essayez de reformuler le sujet.\n")
        return

    print(f"\n{len(resultats)} résultat(s) trouvé(s) :\n" + "-" * 60)
    for i, (article, score) in enumerate(resultats, start=1):
        source_affichee = article.source or "cache local"
        citation_txt = f" · {article.citation_count} citation(s)" if article.citation_count else ""
        print(f"\n[{i}] (pertinence: {score} · source : {source_affichee}{citation_txt})")
        print(f"    {article.reference_academique()}")
        if article.keywords:
            print(f"    Mots-clés : {', '.join(article.keywords[:6])}")
        if article.abstract:
            resume = article.abstract.strip().replace("\n", " ")
            if len(resume) > 220:
                resume = resume[:220] + "…"
            print(f"    Résumé : {resume}")
        if article.url:
            print(f"    Lien : {article.url}")
    print("\n" + "-" * 60)


def main():
    print("=" * 60)
    print(" Assistant de recherche académique — toutes filières")
    print(" Sources : DOAJ, Crossref, OpenAlex, HAL, Semantic Scholar, arXiv")
    print(" Tapez 'quit' pour quitter.")
    print("=" * 60)

    doaj = DOAJClient()
    crossref = CrossrefClient()
    openalex = OpenAlexClient()
    hal = HALClient()
    semantic_scholar = SemanticScholarClient()
    arxiv = ArxivClient()
    index = IndexLocal()
    moteur = MoteurHybride(doaj, index, crossref, openalex, hal, semantic_scholar, arxiv)

    while True:
        try:
            sujet = input("\n🔍 Sujet de recherche > ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not sujet:
            continue
        if sujet.lower() in ("quit", "exit", "q"):
            break

        resultats = moteur.rechercher(sujet)
        afficher_resultats(resultats)

    print("\nÀ bientôt.")


if __name__ == "__main__":
    main()
