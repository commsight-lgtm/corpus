#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Interface graphique — Assistant de recherche académique (toutes filières)
=============================================================================

Interface Tkinter au-dessus du moteur de recherche (shs_corpus_system.py) :
recherche multi-sources (6 API, toutes disciplines), favoris, copie de
référence, ouverture en ligne, export bibliographique (.bib/.ris/.docx +
Zotero), et analyse de document personnel (PDF ou texte collé) pour en
extraire les passages les plus utiles à un sujet de recherche.

Ce fichier IMPORTE shs_corpus_system.py — il doit donc être lancé depuis
le même dossier que ce dernier.

Installation (si pas déjà fait) :
    pip install requests scikit-learn langdetect --break-system-packages
    pip install python-docx --break-system-packages   # export .docx
    pip install pypdf --break-system-packages          # analyse de PDF
    (tkinter est inclus avec Python sur Windows/Mac ; sur Linux :
     sudo apt install python3-tk)

Lancement :
    python3 interface_graphique.py
"""

import threading
import time
import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import filedialog, font as tkfont, messagebox
from typing import List, Optional

from shs_corpus_system import (
    Article, ArxivClient, CrossrefClient, DOAJClient, HALClient, IndexLocal,
    MoteurHybride, OpenAlexClient, SemanticScholarClient, ZoteroClient,
    exporter_bibtex, exporter_docx, exporter_ris,
    extraire_pages_pdf, extraire_passages_pertinents,
)

# --------------------------------------------------------------------------
# Palette et polices — esprit académique sobre
# --------------------------------------------------------------------------

COULEUR_FOND = "#F7F6F3"
COULEUR_FOND_CARTE = "#FFFFFF"
COULEUR_ACCENT = "#1B3A5C"
COULEUR_ACCENT_CLAIR = "#2C5282"
COULEUR_TEXTE = "#1A1A1A"
COULEUR_TEXTE_SECONDAIRE = "#5A5A5A"
COULEUR_BORDURE = "#E0DED8"
COULEUR_LIEN = "#2C5282"
COULEUR_BADGE = "#EDF2F7"
COULEUR_BADGE_CITATIONS = "#FDF3E7"
COULEUR_CITATIONS = "#9C5B12"
COULEUR_ZOTERO = "#7A3E9D"

LOT_AFFICHAGE = 15


class Application(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Assistant de Recherche Académique")
        self.geometry("1000x740")
        self.minsize(780, 560)
        self.configure(bg=COULEUR_FOND)

        self._init_polices()
        self._init_moteur()
        self._construire_interface()

    def _init_polices(self):
        familles_disponibles = set(tkfont.families())
        serif = "Georgia" if "Georgia" in familles_disponibles else "Times New Roman"

        self.police_titre = tkfont.Font(family=serif, size=20, weight="bold")
        self.police_sous_titre = tkfont.Font(family=serif, size=10, slant="italic")
        self.police_resultat_titre = tkfont.Font(family=serif, size=13, weight="bold")
        self.police_section = tkfont.Font(family=serif, size=14, weight="bold")
        self.police_meta = tkfont.Font(family="Segoe UI", size=9)
        self.police_texte = tkfont.Font(family="Segoe UI", size=10)
        self.police_badge = tkfont.Font(family="Segoe UI", size=8, weight="bold")
        self.police_recherche = tkfont.Font(family="Segoe UI", size=12)

    def _init_moteur(self):
        self.doaj = DOAJClient()
        self.crossref = CrossrefClient()
        self.openalex = OpenAlexClient()
        self.hal = HALClient()
        self.semantic_scholar = SemanticScholarClient()
        self.arxiv = ArxivClient()
        self.index = IndexLocal()
        self.moteur = MoteurHybride(
            self.doaj, self.index, self.crossref, self.openalex,
            self.hal, self.semantic_scholar, self.arxiv,
        )

        self.recherche_en_cours = False
        self.mode_affichage = "recherche"
        self.resultats_complets: List[tuple] = []
        self._articles_affiches: List[Article] = []
        self._limite_affichage = LOT_AFFICHAGE
        self._chemin_pdf_document: Optional[Path] = None

    def _construire_interface(self):
        self._construire_en_tete()
        self._construire_barre_recherche()
        self._construire_zone_resultats()
        self._construire_barre_statut()

    def _construire_en_tete(self):
        cadre = tk.Frame(self, bg=COULEUR_FOND, pady=18)
        cadre.pack(fill="x")

        ligne_haut = tk.Frame(cadre, bg=COULEUR_FOND)
        ligne_haut.pack(fill="x", padx=40)

        tk.Frame(ligne_haut, bg=COULEUR_FOND).pack(side="left", fill="x", expand=True)

        self.bouton_favoris = tk.Button(
            ligne_haut, text="☆ Mes favoris", font=self.police_meta,
            bg=COULEUR_FOND, fg=COULEUR_ACCENT, bd=1, relief="solid",
            padx=10, pady=4, cursor="hand2", command=self._basculer_vue_favoris,
        )
        self.bouton_favoris.pack(side="right")

        self.bouton_document = tk.Button(
            ligne_haut, text="📄 Analyser un document", font=self.police_meta,
            bg=COULEUR_FOND, fg=COULEUR_ACCENT, bd=1, relief="solid",
            padx=10, pady=4, cursor="hand2", command=self._basculer_vue_document,
        )
        self.bouton_document.pack(side="right", padx=(0, 8))

        tk.Label(
            cadre, text="Assistant de Recherche Académique",
            font=self.police_titre, fg=COULEUR_ACCENT, bg=COULEUR_FOND,
        ).pack()
        tk.Label(
            cadre, text="Toutes filières — sources : DOAJ, Crossref, OpenAlex, HAL, Semantic Scholar, arXiv",
            font=self.police_sous_titre, fg=COULEUR_TEXTE_SECONDAIRE, bg=COULEUR_FOND,
        ).pack(pady=(2, 0))

    def _construire_barre_recherche(self):
        cadre = tk.Frame(self, bg=COULEUR_FOND, pady=10)
        cadre.pack(fill="x", padx=40)

        conteneur = tk.Frame(cadre, bg=COULEUR_FOND_CARTE, highlightbackground=COULEUR_BORDURE,
                              highlightthickness=1)
        conteneur.pack(fill="x")

        self.champ_recherche = tk.Entry(
            conteneur, font=self.police_recherche, bd=0,
            fg=COULEUR_TEXTE, bg=COULEUR_FOND_CARTE, insertbackground=COULEUR_TEXTE,
        )
        self.champ_recherche.pack(side="left", fill="x", expand=True, padx=(16, 8), pady=12)
        self.champ_recherche.bind("<Return>", lambda e: self.lancer_recherche())
        self.champ_recherche.focus_set()

        self.bouton_recherche = tk.Button(
            conteneur, text="Rechercher", font=self.police_meta,
            bg=COULEUR_ACCENT, fg="white", activebackground=COULEUR_ACCENT_CLAIR,
            activeforeground="white", bd=0, padx=18, pady=8, cursor="hand2",
            command=self.lancer_recherche,
        )
        self.bouton_recherche.pack(side="right", padx=(0, 10), pady=8)

        tk.Label(
            cadre, text="Sujet de recherche, toutes disciplines — en français, arabe ou anglais",
            font=self.police_sous_titre, fg=COULEUR_TEXTE_SECONDAIRE, bg=COULEUR_FOND,
        ).pack(anchor="w", pady=(4, 0))

        cadre_filtres = tk.Frame(cadre, bg=COULEUR_FOND)
        cadre_filtres.pack(fill="x", pady=(8, 0))

        tk.Label(cadre_filtres, text="Trier par :", font=self.police_meta,
                 fg=COULEUR_TEXTE_SECONDAIRE, bg=COULEUR_FOND).pack(side="left")
        self.tri_selection = tk.StringVar(value="Pertinence")
        menu_tri = tk.OptionMenu(
            cadre_filtres, self.tri_selection,
            "Pertinence", "Année (récent d'abord)", "Année (ancien d'abord)", "Citations (plus cité d'abord)",
        )
        menu_tri.config(font=self.police_meta, bg=COULEUR_FOND_CARTE, highlightthickness=0, bd=1)
        menu_tri.pack(side="left", padx=(6, 18))

        tk.Label(cadre_filtres, text="Année min :", font=self.police_meta,
                 fg=COULEUR_TEXTE_SECONDAIRE, bg=COULEUR_FOND).pack(side="left")
        self.champ_annee_min = tk.Entry(cadre_filtres, font=self.police_meta, width=6, bd=1)
        self.champ_annee_min.pack(side="left", padx=(4, 14))

        tk.Label(cadre_filtres, text="Année max :", font=self.police_meta,
                 fg=COULEUR_TEXTE_SECONDAIRE, bg=COULEUR_FOND).pack(side="left")
        self.champ_annee_max = tk.Entry(cadre_filtres, font=self.police_meta, width=6, bd=1)
        self.champ_annee_max.pack(side="left", padx=(4, 14))

        tk.Button(
            cadre_filtres, text="Appliquer", font=self.police_meta,
            bg=COULEUR_BADGE, fg=COULEUR_ACCENT, bd=0, padx=10, pady=3,
            cursor="hand2", command=lambda: self._reafficher_resultats(),
        ).pack(side="left")

    def _construire_zone_resultats(self):
        cadre_externe = tk.Frame(self, bg=COULEUR_FOND)
        cadre_externe.pack(fill="both", expand=True, padx=40, pady=(10, 0))

        self.canvas = tk.Canvas(cadre_externe, bg=COULEUR_FOND, highlightthickness=0)
        barre_defilement = tk.Scrollbar(cadre_externe, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=barre_defilement.set)

        self.canvas.pack(side="left", fill="both", expand=True)
        barre_defilement.pack(side="right", fill="y")

        self.cadre_resultats = tk.Frame(self.canvas, bg=COULEUR_FOND)
        self._fenetre_canvas = self.canvas.create_window((0, 0), window=self.cadre_resultats, anchor="nw")

        self.cadre_resultats.bind(
            "<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        self.canvas.bind(
            "<Configure>", lambda e: self.canvas.itemconfig(self._fenetre_canvas, width=e.width)
        )
        self.canvas.bind_all("<MouseWheel>", self._defiler)

        self._afficher_message_initial()

    def _construire_barre_statut(self):
        self.statut = tk.StringVar(value="Prêt.")
        cadre = tk.Frame(self, bg=COULEUR_BORDURE, height=26)
        cadre.pack(fill="x", side="bottom")
        tk.Label(
            cadre, textvariable=self.statut, font=self.police_meta,
            fg=COULEUR_TEXTE_SECONDAIRE, bg=COULEUR_BORDURE, anchor="w",
        ).pack(fill="x", padx=12, pady=3)

    def _defiler(self, event):
        self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def _vider_resultats(self):
        for enfant in self.cadre_resultats.winfo_children():
            enfant.destroy()

    def _revenir_recherche(self):
        self.mode_affichage = "recherche"
        self._vider_resultats()
        if self.resultats_complets:
            self._reafficher_resultats(reinitialiser_limite=False)
        else:
            self._afficher_message_initial()

    def _copier_texte(self, texte: str):
        self.clipboard_clear()
        self.clipboard_append(texte)
        self.statut.set("Copié dans le presse-papiers.")

    def lancer_recherche(self):
        if self.recherche_en_cours:
            return
        sujet = self.champ_recherche.get().strip()
        if not sujet:
            return

        self.mode_affichage = "recherche"
        self.recherche_en_cours = True
        self.bouton_recherche.config(state="disabled", text="Recherche…")
        self.statut.set(f"Recherche en cours (6 sources) pour : « {sujet} »…")
        self._vider_resultats()
        self._afficher_chargement()

        fil = threading.Thread(target=self._executer_recherche, args=(sujet,), daemon=True)
        fil.start()

    def _executer_recherche(self, sujet: str):
        debut = time.time()
        try:
            resultats = self.moteur.rechercher(sujet)
            erreur = None
        except Exception as e:
            resultats = []
            erreur = str(e)
        duree = time.time() - debut
        self.after(0, lambda: self._traiter_resultats(sujet, resultats, duree, erreur))

    def _traiter_resultats(self, sujet, resultats, duree, erreur):
        self.recherche_en_cours = False
        self.bouton_recherche.config(state="normal", text="Rechercher")

        if erreur:
            self._vider_resultats()
            self.statut.set(f"Erreur pendant la recherche : {erreur}")
            self._afficher_message(f"Une erreur est survenue : {erreur}")
            return

        self.resultats_complets = resultats

        if not resultats:
            self._vider_resultats()
            self.statut.set(f"Aucun résultat pour « {sujet} » ({duree:.1f}s).")
            self._afficher_message(
                "Aucun résultat pertinent trouvé.\nEssayez de reformuler le sujet, ou avec des termes plus généraux."
            )
            return

        self.statut.set(f"{len(resultats)} résultat(s) pour « {sujet} » — {duree:.1f}s.")
        self._reafficher_resultats(reinitialiser_limite=True)

    def _afficher_message_initial(self):
        self._afficher_message(
            "Tapez un sujet de recherche ci-dessus, toutes disciplines confondues.\n\n"
            "Le bouton « 📄 Analyser un document » permet d'importer un PDF (ouvrage, article, "
            "journal) ou de coller un texte, et d'en extraire les passages les plus utiles pour "
            "votre sujet."
        )

    def _afficher_chargement(self):
        self._afficher_message("Recherche en cours…")

    def _afficher_message(self, texte: str):
        tk.Label(
            self.cadre_resultats, text=texte, font=self.police_texte,
            fg=COULEUR_TEXTE_SECONDAIRE, bg=COULEUR_FOND, justify="center", pady=40,
        ).pack(fill="x")

    def _reafficher_resultats(self, reinitialiser_limite: bool = True):
        if self.mode_affichage != "recherche" or not self.resultats_complets:
            return

        if reinitialiser_limite:
            self._limite_affichage = LOT_AFFICHAGE

        self._vider_resultats()

        annee_min = self.champ_annee_min.get().strip()
        annee_max = self.champ_annee_max.get().strip()

        def annee_ok(article: Article) -> bool:
            if not (annee_min or annee_max):
                return True
            if not article.year or not article.year.isdigit():
                return False
            annee = int(article.year)
            if annee_min.isdigit() and annee < int(annee_min):
                return False
            if annee_max.isdigit() and annee > int(annee_max):
                return False
            return True

        resultats = [(a, s) for a, s in self.resultats_complets if annee_ok(a)]

        tri = self.tri_selection.get()
        if tri == "Année (récent d'abord)":
            resultats.sort(key=lambda x: int(x[0].year) if x[0].year and x[0].year.isdigit() else -1,
                            reverse=True)
        elif tri == "Année (ancien d'abord)":
            resultats.sort(key=lambda x: int(x[0].year) if x[0].year and x[0].year.isdigit() else 9999)
        elif tri == "Citations (plus cité d'abord)":
            resultats.sort(key=lambda x: x[0].citation_count or 0, reverse=True)

        if not resultats:
            self._afficher_message("Aucun résultat ne correspond à ces filtres.")
            self._articles_affiches = []
            return

        a_afficher = resultats[: self._limite_affichage]
        for article, score in a_afficher:
            self._ajouter_fiche_resultat(article, score)

        self._articles_affiches = [a for a, _ in a_afficher]

        if len(resultats) > self._limite_affichage:
            restants = len(resultats) - self._limite_affichage
            tk.Button(
                self.cadre_resultats,
                text=f"Afficher {min(LOT_AFFICHAGE, restants)} résultat(s) de plus "
                     f"({restants} restant(s))",
                font=self.police_meta, bg=COULEUR_BADGE, fg=COULEUR_ACCENT,
                bd=0, padx=12, pady=6, cursor="hand2", command=self._afficher_plus,
            ).pack(pady=(4, 10))

        self._ajouter_barre_export(self._articles_affiches)

    def _afficher_plus(self):
        self._limite_affichage += LOT_AFFICHAGE
        self._reafficher_resultats(reinitialiser_limite=False)

    def _ajouter_fiche_resultat(self, article: Article, score: Optional[float]):
        carte = tk.Frame(
            self.cadre_resultats, bg=COULEUR_FOND_CARTE,
            highlightbackground=COULEUR_BORDURE, highlightthickness=1,
        )
        carte.pack(fill="x", pady=6, ipadx=4)

        interieur = tk.Frame(carte, bg=COULEUR_FOND_CARTE, padx=16, pady=12)
        interieur.pack(fill="x")

        ligne_titre = tk.Frame(interieur, bg=COULEUR_FOND_CARTE)
        ligne_titre.pack(fill="x")

        tk.Label(
            ligne_titre, text=article.title, font=self.police_resultat_titre,
            fg=COULEUR_TEXTE, bg=COULEUR_FOND_CARTE, wraplength=560, justify="left", anchor="w",
        ).pack(side="left", anchor="w")

        cadre_badges = tk.Frame(ligne_titre, bg=COULEUR_FOND_CARTE)
        cadre_badges.pack(side="right", anchor="ne")

        if article.citation_count is not None:
            tk.Label(
                cadre_badges, text=f"{article.citation_count} citation(s)",
                font=self.police_badge, fg=COULEUR_CITATIONS, bg=COULEUR_BADGE_CITATIONS,
                padx=8, pady=2,
            ).pack(side="right", padx=(6, 0))

        if score is not None:
            tk.Label(
                cadre_badges, text=f"pertinence {score:.0%}",
                font=self.police_badge, fg=COULEUR_ACCENT, bg=COULEUR_BADGE,
                padx=8, pady=2,
            ).pack(side="right")

        texte_meta = article.reference_academique()
        if article.source:
            texte_meta += f"   ·   source : {article.source}"
        tk.Label(
            interieur, text=texte_meta, font=self.police_meta,
            fg=COULEUR_TEXTE_SECONDAIRE, bg=COULEUR_FOND_CARTE, wraplength=780, justify="left", anchor="w",
        ).pack(fill="x", anchor="w", pady=(4, 0))

        if article.keywords:
            tk.Label(
                interieur, text="Mots-clés : " + ", ".join(article.keywords[:6]),
                font=self.police_meta, fg=COULEUR_ACCENT_CLAIR, bg=COULEUR_FOND_CARTE,
                wraplength=780, justify="left", anchor="w",
            ).pack(fill="x", anchor="w", pady=(4, 0))

        if article.abstract:
            resume = article.abstract.strip().replace("\n", " ")
            if len(resume) > 320:
                resume = resume[:320] + "…"
            tk.Label(
                interieur, text=resume, font=self.police_texte,
                fg=COULEUR_TEXTE, bg=COULEUR_FOND_CARTE, wraplength=780, justify="left", anchor="w",
            ).pack(fill="x", anchor="w", pady=(6, 0))

        ligne_actions = tk.Frame(interieur, bg=COULEUR_FOND_CARTE)
        ligne_actions.pack(fill="x", anchor="w", pady=(8, 0))

        if article.url:
            lien = tk.Label(
                ligne_actions, text="Ouvrir l'article ↗", font=self.police_meta,
                fg=COULEUR_LIEN, bg=COULEUR_FOND_CARTE, cursor="hand2",
            )
            lien.pack(side="left")
            lien.bind("<Button-1>", lambda e, url=article.url: webbrowser.open(url))

        tk.Button(
            ligne_actions, text="Copier la référence", font=self.police_meta,
            bg=COULEUR_BADGE, fg=COULEUR_ACCENT, bd=0, padx=8, pady=2, cursor="hand2",
            command=lambda a=article: self._copier_texte(a.reference_academique()),
        ).pack(side="left", padx=(16, 0))

        est_fav = self.index.est_favori(article.id)
        bouton_favori = tk.Button(
            ligne_actions, text=("★ Favori" if est_fav else "☆ Ajouter aux favoris"),
            font=self.police_meta, bg=COULEUR_BADGE,
            fg=COULEUR_ACCENT if est_fav else COULEUR_TEXTE_SECONDAIRE,
            bd=0, padx=8, pady=2, cursor="hand2",
        )
        bouton_favori.config(command=lambda a=article, b=bouton_favori: self._basculer_favori(a, b))
        bouton_favori.pack(side="left", padx=(8, 0))

    def _basculer_favori(self, article: Article, bouton: tk.Button):
        if self.index.est_favori(article.id):
            self.index.retirer_favori(article.id)
            bouton.config(text="☆ Ajouter aux favoris", fg=COULEUR_TEXTE_SECONDAIRE)
            self.statut.set("Retiré des favoris.")
        else:
            self.index.ajouter_favori(article.id)
            bouton.config(text="★ Favori", fg=COULEUR_ACCENT)
            self.statut.set("Ajouté aux favoris.")

    def _basculer_vue_favoris(self):
        if self.mode_affichage == "favoris":
            self._revenir_recherche()
            return
        self.mode_affichage = "favoris"
        self._vider_resultats()
        favoris = self.index.lister_favoris()
        if not favoris:
            self.statut.set("Aucun favori pour l'instant.")
            self._afficher_message(
                "Vous n'avez encore ajouté aucun article à vos favoris.\n"
                "Cliquez sur ☆ sur une fiche de résultat pour l'ajouter ici."
            )
            self._articles_affiches = []
            return
        self.statut.set(f"{len(favoris)} article(s) en favoris.")
        for article in favoris:
            self._ajouter_fiche_resultat(article, score=None)
        self._articles_affiches = favoris
        self._ajouter_barre_export(favoris)

    def _ajouter_barre_export(self, articles: List[Article]):
        if not articles:
            return
        barre = tk.Frame(self.cadre_resultats, bg=COULEUR_FOND, pady=10)
        barre.pack(fill="x")

        tk.Label(
            barre, text=f"Exporter {len(articles)} référence(s) affichée(s) :",
            font=self.police_meta, fg=COULEUR_TEXTE_SECONDAIRE, bg=COULEUR_FOND,
        ).pack(side="left", padx=(0, 10))

        tk.Button(
            barre, text="Exporter en .bib", font=self.police_meta,
            bg=COULEUR_ACCENT, fg="white", bd=0, padx=12, pady=6, cursor="hand2",
            command=lambda: self._exporter(articles, "bib"),
        ).pack(side="left")

        tk.Button(
            barre, text="Exporter en .ris", font=self.police_meta,
            bg=COULEUR_ACCENT_CLAIR, fg="white", bd=0, padx=12, pady=6, cursor="hand2",
            command=lambda: self._exporter(articles, "ris"),
        ).pack(side="left", padx=(8, 0))

        tk.Button(
            barre, text="Exporter en .docx", font=self.police_meta,
            bg=COULEUR_TEXTE_SECONDAIRE, fg="white", bd=0, padx=12, pady=6, cursor="hand2",
            command=lambda: self._exporter(articles, "docx"),
        ).pack(side="left", padx=(8, 0))

        tk.Button(
            barre, text="🔗 Envoyer vers Zotero", font=self.police_meta,
            bg=COULEUR_ZOTERO, fg="white", bd=0, padx=12, pady=6, cursor="hand2",
            command=lambda: self._envoyer_vers_zotero(articles),
        ).pack(side="left", padx=(8, 0))

    def _exporter(self, articles: List[Article], format_: str):
        extensions = {"bib": ".bib", "ris": ".ris", "docx": ".docx"}
        filetypes_map = {
            "bib": [("BibTeX", "*.bib")],
            "ris": [("RIS", "*.ris")],
            "docx": [("Document Word", "*.docx")],
        }
        chemin_str = filedialog.asksaveasfilename(
            defaultextension=extensions[format_], filetypes=filetypes_map[format_],
            title="Enregistrer la bibliographie",
        )
        if not chemin_str:
            return
        chemin = Path(chemin_str)
        try:
            if format_ == "bib":
                exporter_bibtex(articles, chemin)
            elif format_ == "ris":
                exporter_ris(articles, chemin)
            else:
                exporter_docx(articles, chemin)
            self.statut.set(f"{len(articles)} référence(s) exportée(s) vers {chemin.name}.")
        except RuntimeError as e:
            messagebox.showerror("Export .docx indisponible", str(e))
        except OSError as e:
            messagebox.showerror("Erreur d'export", f"Impossible d'écrire le fichier :\n{e}")

    def _configurer_zotero(self) -> bool:
        cle_existante = self.index.obtenir_parametre("zotero_api_key") or ""
        id_existant = self.index.obtenir_parametre("zotero_library_id") or ""

        fenetre = tk.Toplevel(self)
        fenetre.title("Configuration Zotero")
        fenetre.configure(bg=COULEUR_FOND)
        fenetre.geometry("440x240")

        tk.Label(fenetre, text="Clé API Zotero", font=self.police_meta, bg=COULEUR_FOND,
                 fg=COULEUR_TEXTE_SECONDAIRE, anchor="w").pack(fill="x", padx=16, pady=(16, 2))
        champ_cle = tk.Entry(fenetre, font=self.police_texte, show="•")
        champ_cle.insert(0, cle_existante)
        champ_cle.pack(fill="x", padx=16)

        tk.Label(fenetre, text="Identifiant de bibliothèque (userID)", font=self.police_meta,
                 bg=COULEUR_FOND, fg=COULEUR_TEXTE_SECONDAIRE, anchor="w").pack(fill="x", padx=16, pady=(12, 2))
        champ_id = tk.Entry(fenetre, font=self.police_texte)
        champ_id.insert(0, id_existant)
        champ_id.pack(fill="x", padx=16)

        tk.Label(fenetre, text="Obtenez ces informations sur zotero.org/settings/keys. "
                               "Stockées uniquement en local, non chiffrées.",
                 font=self.police_meta, bg=COULEUR_FOND, fg=COULEUR_TEXTE_SECONDAIRE,
                 wraplength=400, justify="left").pack(fill="x", padx=16, pady=(12, 0))

        resultat = {"ok": False}

        def valider():
            cle = champ_cle.get().strip()
            identifiant = champ_id.get().strip()
            if not cle or not identifiant:
                return
            self.index.definir_parametre("zotero_api_key", cle)
            self.index.definir_parametre("zotero_library_id", identifiant)
            resultat["ok"] = True
            fenetre.destroy()

        tk.Button(fenetre, text="Enregistrer", font=self.police_meta, bg=COULEUR_ACCENT, fg="white",
                  bd=0, padx=12, pady=6, cursor="hand2", command=valider).pack(pady=16)

        fenetre.transient(self)
        fenetre.grab_set()
        self.wait_window(fenetre)
        return resultat["ok"]

    def _envoyer_vers_zotero(self, articles: List[Article]):
        cle = self.index.obtenir_parametre("zotero_api_key")
        identifiant = self.index.obtenir_parametre("zotero_library_id")
        if not cle or not identifiant:
            if not self._configurer_zotero():
                return
            cle = self.index.obtenir_parametre("zotero_api_key")
            identifiant = self.index.obtenir_parametre("zotero_library_id")

        self.statut.set(f"Envoi de {len(articles)} référence(s) vers Zotero…")
        fil = threading.Thread(target=self._executer_envoi_zotero, args=(articles, cle, identifiant), daemon=True)
        fil.start()

    def _executer_envoi_zotero(self, articles, cle, identifiant):
        client = ZoteroClient(cle, identifiant)
        try:
            resume = client.envoyer_articles(articles)
            erreur = None
        except Exception as e:
            resume = None
            erreur = str(e)
        self.after(0, lambda: self._traiter_resultat_zotero(resume, erreur))

    def _traiter_resultat_zotero(self, resume, erreur):
        if erreur:
            self.statut.set(f"Erreur lors de l'envoi vers Zotero : {erreur}")
            return
        self.statut.set(
            f"Zotero : {resume['envoyes']} envoyée(s), "
            f"{resume['ignores_doublons']} déjà présente(s), {resume['echecs']} échec(s)."
        )

    def _basculer_vue_document(self):
        if self.mode_affichage == "document":
            self._revenir_recherche()
            return
        self.mode_affichage = "document"
        self._vider_resultats()
        self._construire_contenu_document()

    def _construire_contenu_document(self):
        tk.Button(
            self.cadre_resultats, text="← Retour à la recherche", font=self.police_meta,
            bg=COULEUR_BADGE, fg=COULEUR_ACCENT, bd=0, padx=10, pady=4, cursor="hand2",
            command=self._revenir_recherche,
        ).pack(anchor="w", pady=(0, 10))

        tk.Label(
            self.cadre_resultats, text="Analyser un document", font=self.police_section,
            fg=COULEUR_ACCENT, bg=COULEUR_FOND, anchor="w",
        ).pack(fill="x", pady=(0, 4))
        tk.Label(
            self.cadre_resultats,
            text="Importez un PDF (ouvrage, article, journal) ou collez un texte (message, extrait...), "
                 "et le système en extrait les passages les plus utiles pour votre sujet de recherche.",
            font=self.police_meta, fg=COULEUR_TEXTE_SECONDAIRE, bg=COULEUR_FOND,
            wraplength=820, justify="left", anchor="w",
        ).pack(fill="x", pady=(0, 14))

        ligne_sujet = tk.Frame(self.cadre_resultats, bg=COULEUR_FOND)
        ligne_sujet.pack(fill="x", pady=(0, 10))
        tk.Label(ligne_sujet, text="Sujet de recherche :", font=self.police_meta,
                 fg=COULEUR_TEXTE_SECONDAIRE, bg=COULEUR_FOND).pack(side="left")
        self.champ_sujet_document = tk.Entry(ligne_sujet, font=self.police_meta, bd=1)
        self.champ_sujet_document.insert(0, self.champ_recherche.get().strip())
        self.champ_sujet_document.pack(side="left", padx=(6, 0), fill="x", expand=True)

        ligne_pdf = tk.Frame(self.cadre_resultats, bg=COULEUR_FOND)
        ligne_pdf.pack(fill="x", pady=(0, 6))
        tk.Button(
            ligne_pdf, text="📄 Choisir un PDF…", font=self.police_meta, bg=COULEUR_BADGE, fg=COULEUR_ACCENT,
            bd=0, padx=10, pady=4, cursor="hand2", command=self._choisir_pdf_document,
        ).pack(side="left")
        self.label_pdf_choisi = tk.Label(
            ligne_pdf,
            text=self._chemin_pdf_document.name if self._chemin_pdf_document else "Aucun PDF sélectionné",
            font=self.police_meta, fg=COULEUR_TEXTE_SECONDAIRE, bg=COULEUR_FOND,
        )
        self.label_pdf_choisi.pack(side="left", padx=(10, 0))

        tk.Label(
            self.cadre_resultats, text="— ou collez un texte ci-dessous —", font=self.police_meta,
            fg=COULEUR_TEXTE_SECONDAIRE, bg=COULEUR_FOND,
        ).pack(anchor="w", pady=(10, 4))
        self.texte_document_colle = tk.Text(
            self.cadre_resultats, font=self.police_texte, height=8, wrap="word", bd=1, relief="solid",
        )
        self.texte_document_colle.pack(fill="x", pady=(0, 10))

        tk.Button(
            self.cadre_resultats, text="Extraire les passages utiles", font=self.police_meta,
            bg=COULEUR_ACCENT, fg="white", bd=0, padx=14, pady=8, cursor="hand2",
            command=self._lancer_extraction_document,
        ).pack(anchor="w", pady=(0, 16))

        self.cadre_resultats_document = tk.Frame(self.cadre_resultats, bg=COULEUR_FOND)
        self.cadre_resultats_document.pack(fill="x")

    def _choisir_pdf_document(self):
        chemin_str = filedialog.askopenfilename(filetypes=[("Fichiers PDF", "*.pdf")], title="Choisir un PDF")
        if not chemin_str:
            return
        self._chemin_pdf_document = Path(chemin_str)
        self.label_pdf_choisi.config(text=self._chemin_pdf_document.name, fg=COULEUR_ACCENT)

    def _lancer_extraction_document(self):
        sujet = self.champ_sujet_document.get().strip()
        if not sujet:
            self.statut.set("Indiquez un sujet de recherche pour cibler l'extraction.")
            return
        texte_colle = self.texte_document_colle.get("1.0", tk.END).strip()
        if not self._chemin_pdf_document and not texte_colle:
            self.statut.set("Choisissez un PDF ou collez un texte à analyser.")
            return

        self.statut.set("Analyse du document en cours…")
        for enfant in self.cadre_resultats_document.winfo_children():
            enfant.destroy()
        tk.Label(
            self.cadre_resultats_document, text="Analyse en cours (peut prendre un moment pour un long document)…",
            font=self.police_texte, fg=COULEUR_TEXTE_SECONDAIRE, bg=COULEUR_FOND,
        ).pack(anchor="w")

        fil = threading.Thread(
            target=self._executer_extraction_document,
            args=(sujet, self._chemin_pdf_document, texte_colle), daemon=True,
        )
        fil.start()

    def _executer_extraction_document(self, sujet: str, chemin_pdf: Optional[Path], texte_colle: str):
        try:
            unites = []
            if chemin_pdf:
                pages = extraire_pages_pdf(chemin_pdf)
                unites.extend({"texte": p, "page": i + 1} for i, p in enumerate(pages))
            if texte_colle:
                unites.append({"texte": texte_colle, "page": None})
            passages = extraire_passages_pertinents(unites, sujet, max_resultats=15)
            erreur = None
        except RuntimeError as e:
            passages = []
            erreur = str(e)
        except Exception as e:
            passages = []
            erreur = str(e)
        self.after(0, lambda: self._traiter_extraction_document(passages, erreur))

    def _traiter_extraction_document(self, passages: List[dict], erreur: Optional[str]):
        for enfant in self.cadre_resultats_document.winfo_children():
            enfant.destroy()

        if erreur:
            self.statut.set("Erreur lors de l'analyse du document.")
            tk.Label(
                self.cadre_resultats_document, text=erreur, font=self.police_texte,
                fg=COULEUR_TEXTE_SECONDAIRE, bg=COULEUR_FOND, wraplength=820, justify="left",
            ).pack(anchor="w")
            return

        if not passages:
            self.statut.set("Aucun passage pertinent trouvé.")
            tk.Label(
                self.cadre_resultats_document,
                text="Aucun passage suffisamment lié au sujet n'a été trouvé dans ce document. "
                     "Essayez un sujet plus proche du vocabulaire employé dans le texte.",
                font=self.police_texte, fg=COULEUR_TEXTE_SECONDAIRE, bg=COULEUR_FOND,
                wraplength=820, justify="left",
            ).pack(anchor="w")
            return

        self.statut.set(f"{len(passages)} passage(s) pertinent(s) trouvé(s).")
        for p in passages:
            ligne = tk.Frame(
                self.cadre_resultats_document, bg=COULEUR_FOND_CARTE,
                highlightbackground=COULEUR_BORDURE, highlightthickness=1,
            )
            ligne.pack(fill="x", pady=4)
            interieur = tk.Frame(ligne, bg=COULEUR_FOND_CARTE, padx=12, pady=8)
            interieur.pack(fill="x")

            entete = f"pertinence {p['score']:.0%}"
            if p.get("page"):
                entete += f"   ·   page {p['page']}"
            tk.Label(
                interieur, text=entete, font=self.police_meta, fg=COULEUR_ACCENT, bg=COULEUR_FOND_CARTE,
                anchor="w",
            ).pack(fill="x", anchor="w")
            tk.Label(
                interieur, text=f"« {p['texte']} »", font=self.police_texte, fg=COULEUR_TEXTE,
                bg=COULEUR_FOND_CARTE, wraplength=780, justify="left", anchor="w",
            ).pack(fill="x", anchor="w", pady=(4, 6))
            tk.Button(
                interieur, text="Copier le passage", font=self.police_meta, bg=COULEUR_BADGE,
                fg=COULEUR_ACCENT, bd=0, padx=8, pady=2, cursor="hand2",
                command=lambda t=p["texte"]: self._copier_texte(str(t)),
            ).pack(anchor="e")


def main():
    app = Application()
    app.mainloop()


if __name__ == "__main__":
    main()
