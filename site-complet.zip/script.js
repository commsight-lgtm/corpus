// ---------------------------------------------------------------
// Téléchargement Windows : déclenche le téléchargement du .zip
// (placez AssistantRechercheAcademique-Windows.zip à côté de ce
// fichier index.html, dans le même dossier, pour que le lien
// fonctionne une fois la page mise en ligne).
// ---------------------------------------------------------------

const NOM_FICHIER_WINDOWS = "AssistantRechercheAcademique-Windows.zip";

document.getElementById("bouton-telecharger-windows").addEventListener("click", () => {
  const lien = document.createElement("a");
  lien.href = NOM_FICHIER_WINDOWS;
  lien.download = NOM_FICHIER_WINDOWS;
  document.body.appendChild(lien);
  lien.click();
  document.body.removeChild(lien);

  document.getElementById("etapes-installation").hidden = false;
  document.getElementById("etapes-installation").scrollIntoView({ behavior: "smooth", block: "nearest" });
});

// ---------------------------------------------------------------
// iOS : pas de version disponible pour le moment (Tkinter ne peut
// pas tourner sur iPhone/iPad). On le dit clairement plutôt que de
// proposer un faux téléchargement.
// ---------------------------------------------------------------

const boutonIOS = document.getElementById("bouton-telecharger-ios");
const noteIOS = document.getElementById("ios-note");

boutonIOS.addEventListener("click", () => {
  boutonIOS.textContent = "Merci — on vous préviendra";
  boutonIOS.disabled = true;
  noteIOS.textContent =
    "Aucune inscription n'est encore enregistrée par ce bouton pour l'instant " +
    "(la page n'a pas de serveur). Revenez suivre l'avancement ici, ou contactez-nous directement.";
});
